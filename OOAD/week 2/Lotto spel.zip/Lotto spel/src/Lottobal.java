public class Lottobal {

    private int balNummer;

    public int getBalNummer() {
        return balNummer;
    }
}
