public class Scorebord {


    public void plaatsBal(Lottobal bal) {
        System.out.println("Plaats bal " + bal.getBalNummer() + " op scorebord");
    }
    public void maakLeeg() {
        System.out.println("Maak scorebord leeg");
    }

    public void plaatsBonusBal(Lottobal bal) {
        System.out.println("Plaats bonusbal " + bal.getBalNummer() + " op scorebord");
    }

    public void sorteerBallen() {
        System.out.println("Sorteer ballen op scorebord");
    }


}
