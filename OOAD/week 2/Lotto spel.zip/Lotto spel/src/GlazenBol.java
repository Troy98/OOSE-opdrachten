public class GlazenBol {

    int capaciteit = 45;


    public void verzamelAlleBallen() {

    }

    public Lottobal schepBal() {
        return new Lottobal();
    }
}
